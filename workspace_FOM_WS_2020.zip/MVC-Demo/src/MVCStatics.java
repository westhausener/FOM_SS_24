public class MVCStatics {
     
    // Actionscommands
    public static final String ACTION_DEC = "action_dec";
    public static final String ACTION_INC = "action_inc";
}