public class MVCEnergie {
 
    /**
     * @param args
     */
    public static void main(String[] args) {
        new MVCController();
    }
}