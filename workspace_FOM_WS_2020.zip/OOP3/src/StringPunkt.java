
public class StringPunkt {

	public static void main(String[] args) {
		
		String s;
		
		s = "Hallo Welt!";
		
		// Nach dem Tippen des Punktes schlägt Eclipse Attribute und Methoden vor
		String s2 = s.substring(4);
		System.out.println(s);
		System.out.println(s2);
		
	}

}
