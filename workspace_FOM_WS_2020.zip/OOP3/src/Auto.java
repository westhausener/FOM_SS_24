
public class Auto {
	
	int ps;
	String hersteller;
	
	static int anzahl;
	
	
}
