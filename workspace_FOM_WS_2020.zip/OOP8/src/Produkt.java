// Datei: Produkt.java

public class Produkt
{
   protected String name;
   protected int tiefe;
   protected int hoehe;
   protected int gewicht;
   protected int breite;
   
   
   
   
   // Konstruktor
   public Produkt(String name, int tiefe, int hoehe, int gewicht, int breite){
	   
	   this.name = name;
	   this.tiefe = tiefe;
	   this.hoehe = hoehe;
	   this.gewicht = gewicht;
	   this.breite = breite;
   }
}
