
public abstract class GeometrischeFigur2d {

	protected int x;
	protected int y;
	
	// abstrakte Methode
	public abstract int berechneFlaeche();
	
	
	
}
