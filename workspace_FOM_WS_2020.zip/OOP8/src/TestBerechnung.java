// Datei: TestBerechnung.java

public class TestBerechnung
{
   public static void main (String [] args)
   {
      Kreis kreisRef = new Kreis (5);
      Rechteck rechteckRef = new Rechteck (10, 6);
      
      kreisRef.print();
      rechteckRef.print();
   }
}
