
public class EingabeTest {

	public static void main(String[] args) {
		
		int i = Tools.intEingabe();
		
		System.out.println("Wert: "+i);
		
	}

}
