
public class Aufg_04_03 {

	   public static void main (String[] args){
		   
		  // beides sind Integer-Typen 
	      System.out.println ("Division von 10 durch 12: " + (10/12));
	      
	      // 10. ist ein float-Datentyp, daher automatische (implizite) Konvertierung des Ergebnisses
	      System.out.println ("Division von 10. durch 12: " + (10./12));
	      
	      // 12. ist ein float-Datentyp, daher automatische (implizite) Konvertierung des Ergebnisses
	      System.out.println ("Division von 10 durch 12.: " + (10/12.));
	   }
}
