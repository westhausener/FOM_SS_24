// Datei: JWindowTest.java

import javax.swing.*;

public class JWindowTest
{
   public static void main (String[] args)
   {
      JWindow window = new JWindow();
      window.setSize (410, 150);
      window.setVisible (true);
   }
}
