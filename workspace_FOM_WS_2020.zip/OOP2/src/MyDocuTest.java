
/**
 * 
 * @author oliver
 * @version 1.0
 * 
 * Diese Klasse dient zur Uebung von Javadoc.
 */
public class MyDocuTest{
    
	/**
	 * Gibt die aktuelle Jahreszahl an
	 */
	public int jahr;

	/**
	 * Diese Methode erhaelt eine Zeichenkette und gibt diese ueber die Systemausgabe aus.
	 * @param s Ausgabezeichenkette
	 */
	public void print(String s){
        System.out.println("Ausgabe: "+s);
    }
}