
public class HalloWelt3 {

	public static void main(String[] args) {

		String susi = "Hallo Olli!";

		System.out.println("Ausgabe: "+susi);

	}

}
