
/** Ich bin ein Kommentar und erlaeutere die Klasse DocuTest1 */
public class DocuTest1
{
   /** Ich bin ein Kommentar und erlaeutere das Datenfeld x   */
   public int x;
   
   /**
    * Bla Bla
    * @param i Ich bin der Parameter i!
    * @param j bla bla
    * @return Ich bin das Ergebnis!
    */
   public int berechne(int i, int j)
   {
      // Weitere Anweisungen
	   return 0;
   }
}