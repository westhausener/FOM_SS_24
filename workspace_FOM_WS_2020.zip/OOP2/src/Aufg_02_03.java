
public class Aufg_02_03 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int zahl = 7;
		
		double flaeche = Math.PI * zahl * zahl;
		
        System.out.println("Bildschirmtext");
        // Semikolon vergessen -> Fehler wird angezeigt
        System.out.println(zahl);
        System.out.println("Toll, oder?");

	}

}
