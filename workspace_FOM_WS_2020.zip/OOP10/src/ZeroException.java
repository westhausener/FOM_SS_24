
public class ZeroException extends Exception {
	

	public ZeroException(){
		
		super("Der Wert 0 ist nicht erlaubt!");
	}
}
