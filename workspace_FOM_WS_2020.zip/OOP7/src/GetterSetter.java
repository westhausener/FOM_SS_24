public class GetterSetter {
	
	private int ps;
	private String hersteller;
	
	private static int anzahl;

	
	
	
}