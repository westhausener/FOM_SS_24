
public class Klausur {

		private String name;
		private int matrikelnummer;
		private String modul;
		
		public Klausur(String name, int matrikelnummer, String modul) {
			
			this.name = name;
			this.matrikelnummer = matrikelnummer;
			this.modul = modul;
		}
		
		

}
