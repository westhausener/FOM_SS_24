package fliegen;

public class Vogel implements Fliegen{

	public void fliegen() {
		System.out.println("FlatterFlatter");
		
	}

}
