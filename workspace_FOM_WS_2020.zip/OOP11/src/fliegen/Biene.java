package fliegen;

public class Biene implements Fliegen{


	public void fliegen() {
		System.out.println("SummSumm");
		
	}

}
