package fliegen;
	
public interface Fliegen{
	
	public  void fliegen();
}
