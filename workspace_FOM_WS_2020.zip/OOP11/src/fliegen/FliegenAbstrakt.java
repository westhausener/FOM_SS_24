package fliegen;

public abstract class FliegenAbstrakt {

	abstract void fliegen();
	
}
