
public class Trompete implements Musikinstrument{

	@Override
	public void spieleInstrument() {
		
		System.out.println("Trööööt");
		
	}


}
 