// Datei: Musikantenstadl.java

public class Musikantenstadl{
	
   public static void main (String[] args){
	   
	   // Trommel und Trompete erzeugen und abspielen lassen
	   Trommel t1 = new Trommel();
	   Trompete t2 = new Trompete();
	   
	   t1.spieleInstrument();
	   t2.spieleInstrument();
   }
}












