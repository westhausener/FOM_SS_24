
public class Trommel implements Musikinstrument {

	@Override
	public void spieleInstrument() {
		
		System.out.println("Tamm tamm");
		
	}


	
}
