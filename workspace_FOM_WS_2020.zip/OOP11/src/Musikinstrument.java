
public interface Musikinstrument{
  
	public void spieleInstrument();
}
