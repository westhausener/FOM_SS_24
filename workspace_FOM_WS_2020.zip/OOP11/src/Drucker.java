
public interface Drucker {
	
	public void drucke(String s);
	public int getSeiten();

}
